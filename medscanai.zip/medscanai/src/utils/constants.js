export const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://your-production-api.com' 
  : 'http://localhost:3001'

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  SIGNUP: '/signup',
  DASHBOARD: '/dashboard',
  CAMERA: '/camera',
  RESULTS: '/results'
}

export const STORAGE_KEYS = {
  TOKEN: 'token',
  USER_DATA: 'userData'
}