import React from 'react'
import { Link } from 'react-router-dom'
import Header from '../components/common/Header'
import Footer from '../components/common/Footer'
import { useAuth } from '../context/AuthContext'

export default function Dashboard() {
  const { user } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome, {user?.name}!
          </h1>
          <p className="text-gray-600 mb-8">
            Ready to analyze some images?
          </p>
          
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Link
              to="/camera"
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition duration-300 border-2 border-transparent hover:border-blue-500"
            >
              <div className="text-4xl mb-4">📷</div>
              <h3 className="text-xl font-semibold mb-2">Camera Capture</h3>
              <p className="text-gray-600">Use your camera to capture new images for analysis</p>
            </Link>
            
            <div className="bg-white p-6 rounded-lg shadow-md border-2 border-gray-200">
              <div className="text-4xl mb-4">📊</div>
              <h3 className="text-xl font-semibold mb-2">Analysis History</h3>
              <p className="text-gray-600">View your previous image analyses (Coming Soon)</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Quick Start</h3>
            <ol className="list-decimal list-inside space-y-2 text-gray-600">
              <li>Click on "Camera Capture" to start analyzing images</li>
              <li>Use your camera or upload an existing image</li>
              <li>Get instant AI-powered analysis results</li>
            </ol>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}