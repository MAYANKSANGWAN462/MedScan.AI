import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import Header from '../components/common/Header'
import Footer from '../components/common/Footer'
import Loader from '../components/common/Loader'

export default function Results() {
  const location = useLocation()
  const navigate = useNavigate()
  const { image } = location.state || {}
  
  // Mock analysis results - replace with actual ML model results
  const analysisResults = {
    confidence: 85,
    label: 'Sample Object',
    description: 'This appears to be a sample object detected by the AI model.',
    details: [
      { label: 'Confidence Score', value: '85%' },
      { label: 'Category', value: 'Object Detection' },
      { label: 'Processing Time', value: '2.3s' }
    ]
  }

  if (!image) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">No Image Found</h2>
            <button 
              onClick={() => navigate('/camera')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg"
            >
              Go Back to Camera
            </button>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <div className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center text-gray-900 mb-8">
            Analysis Results
          </h1>
          
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Original Image */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-4">Original Image</h3>
              <img 
                src={image} 
                alt="Analyzed" 
                className="w-full h-auto rounded-lg"
              />
            </div>
            
            {/* Analysis Results */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-4">Analysis</h3>
              
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-700">Confidence</span>
                  <span className="font-semibold">{analysisResults.confidence}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full" 
                    style={{ width: `${analysisResults.confidence}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Label</h4>
                  <p className="text-gray-700">{analysisResults.label}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Description</h4>
                  <p className="text-gray-700">{analysisResults.description}</p>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Details</h4>
                  <div className="space-y-2">
                    {analysisResults.details.map((detail, index) => (
                      <div key={index} className="flex justify-between">
                        <span className="text-gray-600">{detail.label}</span>
                        <span className="font-semibold">{detail.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex gap-4 justify-center">
            <button 
              onClick={() => navigate('/camera')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition duration-300"
            >
              Analyze Another Image
            </button>
            <button 
              onClick={() => navigate('/dashboard')}
              className="border border-gray-600 text-gray-600 hover:bg-gray-50 font-semibold py-3 px-8 rounded-lg transition duration-300"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  )
}