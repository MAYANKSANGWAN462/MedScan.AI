import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from '../components/common/Header'
import Footer from '../components/common/Footer'
import CameraPreview from '../components/camera/CameraPreview'
import ImageUpload from '../components/camera/ImageUpload'

export default function Camera() {
  const [capturedImage, setCapturedImage] = useState(null)
  const [activeTab, setActiveTab] = useState('camera')
  const navigate = useNavigate()

  const handleAnalyze = () => {
    // TODO: Send image to ML model for analysis
    console.log('Analyzing image:', capturedImage)
    
    // Navigate to results page with image data
    navigate('/results', { state: { image: capturedImage } })
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <div className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center text-gray-900 mb-8">
          Capture or Upload Image
        </h1>
        
        {/* Tab Navigation */}
        <div className="flex border-b border-gray-200 mb-8 max-w-2xl mx-auto">
          <button
            onClick={() => setActiveTab('camera')}
            className={`flex-1 py-4 font-semibold text-center ${
              activeTab === 'camera'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-gray-800'
            } transition duration-300`}
          >
            Camera
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex-1 py-4 font-semibold text-center ${
              activeTab === 'upload'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-gray-800'
            } transition duration-300`}
          >
            Upload
          </button>
        </div>
        
        {/* Content */}
        <div className="max-w-2xl mx-auto">
          {activeTab === 'camera' ? (
            <CameraPreview onCapture={setCapturedImage} />
          ) : (
            <ImageUpload onUpload={setCapturedImage} />
          )}
          
          {capturedImage && (
            <div className="mt-8 p-6 bg-white rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-4">Preview</h3>
              <img 
                src={capturedImage} 
                alt="Captured" 
                className="max-w-full h-auto rounded-lg mb-4"
              />
              <div className="flex gap-4">
                <button 
                  onClick={() => setCapturedImage(null)}
                  className="flex-1 border border-gray-600 text-gray-600 hover:bg-gray-50 font-semibold py-3 px-6 rounded-lg transition duration-300"
                >
                  Retake
                </button>
                <button 
                  onClick={handleAnalyze}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300"
                >
                  Analyze Image
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <Footer />
    </div>
  )
}