import React from 'react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link to="/" className="text-2xl font-bold text-white">
              YourApp
            </Link>
            <p className="text-gray-400 mt-2">
              AI-powered image analysis made simple
            </p>
          </div>
          
          <div className="flex space-x-6">
            <Link to="/" className="text-gray-400 hover:text-white transition duration-300">
              Home
            </Link>
            <Link to="/camera" className="text-gray-400 hover:text-white transition duration-300">
              Try Demo
            </Link>
            <Link to="/login" className="text-gray-400 hover:text-white transition duration-300">
              Login
            </Link>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400">
          <p>&copy; 2024 YourApp. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}