import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import logo from "../../../public/logo.png";

export default function Header() {
  const { isAuthenticated, logout, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/");
    setIsMobileMenuOpen(false);
  };

  const isActiveRoute = (path) => {
    return location.pathname === path;
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex items-center gap-2"
            onClick={closeMobileMenu}
          >
            <img src={logo} alt="MedScan.AI Logo" className="h-8 md:h-10 w-auto" />
            <span className="text-xl md:text-2xl font-bold text-blue-600">MedScan.AI</span>
          </Link>

          {/* Desktop Navigation - Hidden on mobile */}
          <nav className="hidden lg:flex items-center space-x-4 xl:space-x-6">
            {isAuthenticated ? (
              <>
                {/* Centered Navigation for Desktop */}
                <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-full p-1 shadow-inner mr-4">
                  <Link
                    to="/"
                    className={`px-4 xl:px-6 py-2 rounded-full transition-all duration-300 font-semibold text-sm xl:text-base ${
                      isActiveRoute("/")
                        ? "bg-white text-blue-600 shadow-md"
                        : "text-gray-700 hover:text-blue-600 hover:bg-white/80"
                    }`}
                  >
                    Home
                  </Link>
                  <Link
                    to="/camera"
                    className={`px-4 xl:px-6 py-2 rounded-full transition-all duration-300 font-semibold text-sm xl:text-base ${
                      isActiveRoute("/camera")
                        ? "bg-white text-blue-600 shadow-md"
                        : "text-gray-700 hover:text-blue-600 hover:bg-white/80"
                    }`}
                  >
                    Camera
                  </Link>
                </div>

                <Link
                  to="/dashboard"
                  className={`px-3 xl:px-4 py-2 rounded-lg transition-all duration-300 font-semibold text-sm xl:text-base ${
                    isActiveRoute("/dashboard")
                      ? "bg-blue-100 text-blue-600"
                      : "text-gray-700 hover:text-blue-600 hover:bg-blue-50"
                  }`}
                >
                  Dashboard
                </Link>
                
                <div className="flex items-center space-x-3">
                  <span className="text-gray-700 text-sm xl:text-base hidden xl:block">
                    Hello, {user?.name}
                  </span>
                  <button
                    onClick={handleLogout}
                    className="text-gray-700 hover:text-red-600 transition duration-300 font-semibold text-sm xl:text-base"
                  >
                    Logout
                  </button>
                </div>
              </>
            ) : (
              <>
                {/* Centered Navigation for Desktop */}
                <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-full p-1 shadow-inner mr-4">
                  <Link
                    to="/"
                    className={`px-4 xl:px-6 py-2 rounded-full transition-all duration-300 font-semibold text-sm xl:text-base ${
                      isActiveRoute("/")
                        ? "bg-white text-blue-600 shadow-md"
                        : "text-gray-700 hover:text-blue-600 hover:bg-white/80"
                    }`}
                  >
                    Home
                  </Link>
                  <Link
                    to="/camera"
                    className={`px-4 xl:px-6 py-2 rounded-full transition-all duration-300 font-semibold text-sm xl:text-base ${
                      isActiveRoute("/camera")
                        ? "bg-white text-blue-600 shadow-md"
                        : "text-gray-700 hover:text-blue-600 hover:bg-white/80"
                    }`}
                  >
                    Try Demo
                  </Link>
                </div>

                <Link
                  to="/login"
                  className={`px-3 xl:px-4 py-2 rounded-lg transition-all duration-300 font-semibold text-sm xl:text-base ${
                    isActiveRoute("/login")
                      ? "bg-blue-100 text-blue-600"
                      : "text-gray-700 hover:text-blue-600 hover:bg-blue-50"
                  }`}
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 xl:px-6 py-2 rounded-lg transition-all duration-300 font-semibold text-sm xl:text-base shadow-md hover:shadow-lg"
                >
                  Sign Up
                </Link>
              </>
            )}
          </nav>

          {/* Mobile Menu Button - Visible only on mobile */}
          <button
            onClick={toggleMobileMenu}
            className="lg:hidden p-2 rounded-lg text-gray-700 hover:bg-gray-100 transition duration-300"
            aria-label="Toggle menu"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu - Slides down */}
        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t pt-4 animate-slideDown">
            <div className="flex flex-col space-y-3">
              {isAuthenticated ? (
                <>
                  <Link
                    to="/"
                    onClick={closeMobileMenu}
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      isActiveRoute("/")
                        ? "bg-blue-100 text-blue-600 border-2 border-blue-200"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    Home
                  </Link>
                  <Link
                    to="/camera"
                    onClick={closeMobileMenu}
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      isActiveRoute("/camera")
                        ? "bg-blue-100 text-blue-600 border-2 border-blue-200"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    Camera
                  </Link>
                  <Link
                    to="/dashboard"
                    onClick={closeMobileMenu}
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      isActiveRoute("/dashboard")
                        ? "bg-blue-100 text-blue-600 border-2 border-blue-200"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    Dashboard
                  </Link>
                  <div className="px-4 py-3 text-center text-gray-700 border-t mt-2 pt-3">
                    Hello, {user?.name}
                  </div>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center text-red-600 hover:bg-red-50 border border-red-200"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/"
                    onClick={closeMobileMenu}
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      isActiveRoute("/")
                        ? "bg-blue-100 text-blue-600 border-2 border-blue-200"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    Home
                  </Link>
                  <Link
                    to="/camera"
                    onClick={closeMobileMenu}
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      isActiveRoute("/camera")
                        ? "bg-blue-100 text-blue-600 border-2 border-blue-200"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    Try Demo
                  </Link>
                  <Link
                    to="/login"
                    onClick={closeMobileMenu}
                    className={`px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center ${
                      isActiveRoute("/login")
                        ? "bg-blue-100 text-blue-600 border-2 border-blue-200"
                        : "text-gray-700 hover:bg-blue-50 hover:text-blue-600"
                    }`}
                  >
                    Login
                  </Link>
                  <Link
                    to="/signup"
                    onClick={closeMobileMenu}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 py-3 rounded-lg transition-all duration-300 font-semibold text-center shadow-md"
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}