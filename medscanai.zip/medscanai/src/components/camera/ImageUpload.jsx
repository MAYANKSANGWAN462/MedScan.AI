import React, { useState, useRef } from 'react'

export default function ImageUpload({ onUpload }) {
  const [preview, setPreview] = useState(null)
  const fileInputRef = useRef(null)

  const handleFileSelect = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target.result)
        onUpload(e.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleDrop = (event) => {
    event.preventDefault()
    const file = event.dataTransfer.files[0]
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target.result)
        onUpload(e.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleDragOver = (event) => {
    event.preventDefault()
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelect}
        accept="image/*"
        className="hidden"
      />
      
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={triggerFileInput}
        className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-400 transition duration-300"
      >
        {preview ? (
          <div>
            <img 
              src={preview} 
              alt="Preview" 
              className="max-w-full h-48 object-cover rounded-lg mx-auto mb-4"
            />
            <p className="text-gray-600">Click or drag to change image</p>
          </div>
        ) : (
          <div>
            <div className="text-6xl mb-4">📁</div>
            <p className="text-gray-600">Click or drag and drop to upload image</p>
            <p className="text-sm text-gray-500 mt-2">Supports: JPG, PNG, WebP</p>
          </div>
        )}
      </div>
      
      {!preview && (
        <button
          onClick={triggerFileInput}
          className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300"
        >
          Choose File
        </button>
      )}
    </div>
  )
}