import React from 'react'
import { useCamera } from '../../hooks/usecamera.js'


export default function CameraPreview({ onCapture }) {
  const { videoRef, isCameraOn, startCamera, stopCamera, captureImage } = useCamera()

  const handleCapture = () => {
    const imageData = captureImage()
    if (imageData) {
      onCapture(imageData)
      stopCamera()
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="aspect-video bg-gray-200 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
        {isCameraOn ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-center text-gray-500">
            <div className="text-6xl mb-4">📷</div>
            <p>Camera is off</p>
          </div>
        )}
      </div>
      
      <div className="flex gap-4">
        {!isCameraOn ? (
          <button
            onClick={startCamera}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300"
          >
            Start Camera
          </button>
        ) : (
          <>
            <button
              onClick={handleCapture}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300"
            >
              Capture
            </button>
            <button
              onClick={stopCamera}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300"
            >
              Stop Camera
            </button>
          </>
        )}
      </div>
    </div>
  )
}