import { useState, useRef, useCallback } from 'react'

export const useCamera = () => {
  const videoRef = useRef(null)
  const [isCameraOn, setIsCameraOn] = useState(false)
  const [stream, setStream] = useState(null)

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      })
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        setStream(mediaStream)
        setIsCameraOn(true)
      }
    } catch (error) {
      console.error('Error accessing camera:', error)
      throw new Error('Unable to access camera. Please check permissions.')
    }
  }, [])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop())
      setStream(null)
      setIsCameraOn(false)
    }
  }, [stream])

  const captureImage = useCallback(() => {
    if (!videoRef.current) return null
    
    const video = videoRef.current
    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    const ctx = canvas.getContext('2d')
    ctx.drawImage(video, 0, 0)
    
    return canvas.toDataURL('image/png')
  }, [])

  return {
    videoRef,
    isCameraOn,
    startCamera,
    stopCamera,
    captureImage
  }
}