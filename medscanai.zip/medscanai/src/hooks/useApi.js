import { useState } from 'react'

export const useApi = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const callApi = async (apiCall, onSuccess, onError) => {
    setLoading(true)
    setError(null)
    
    try {
      const result = await apiCall()
      if (onSuccess) onSuccess(result)
      return result
    } catch (err) {
      setError(err.message)
      if (onError) onError(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  return {
    loading,
    error,
    callApi
  }
}